/*En este archivo .sql encontrarás todos los comandos que ejecutaremos durante el desarrollo de nuestro entrenamiento. 

Por el momento, te invitamos a preparar el ambiente para que puedas desarrollar todos los ejercicios. 

¡Te deseo muchos éxitos en tus estudios!*/
