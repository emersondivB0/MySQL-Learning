# Comandos DML: Manipulación de datos con MySQL

Este repositorio contiene todos los archivos referentes al curso de Alura sobre Comandos DML: Manipulación de datos con MySQL.
